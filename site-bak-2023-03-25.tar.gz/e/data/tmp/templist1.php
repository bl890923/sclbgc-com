<?php
if(!defined('InEmpireCMS'))
{
	exit();
}
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="viewport" content="width=device-width;minimum-scale=1,maximum-scale=1,initial-scale=1,user-scalable=no"/>
    <meta name="applicable-device" content="pc,mobile">
    <title>[!--pagetitle--] - 南充市丽邦装饰工程有限公司</title>
    <meta name="keywords" content="[!--pagekey--] />
    <meta name="description" content="[!--pagedes--]" />
    <link rel="stylesheet" type="text/css" href="/css/reset.css"/>
    <link rel="stylesheet" type="text/css" href="/css/css.css"/>
    <link rel="stylesheet" type="text/css" href="/css/responsive.css"/>
    <link rel="stylesheet" type="text/css" href="/css/jquery-ui.css"/>
    <script type="text/javascript" src="/js/jquery.min.js"></script>
    <script type="text/javascript" src="/js/jquery-ui.js"></script>
    <script src="/js/jquery.SuperSlide.2.1.1.js" type="text/javascript"></script>
    <script type="text/javascript" src="/js/jquery.pagination.js"></script>

    <script src="/js/Search.js" type="text/javascript"></script>
</head>

<body>
<div class="header">
    <div class="header_center">
        <h1 class="logo wow zoomIn"><a href="/"><img width="64px" height="64px" src="/images/logo.png" title="南充市丽邦装饰工程有限公司" alt="南充市丽邦装饰工程有限公司" /><img class="logo_txt" src="/images/logo_txt.png" alt=""></a></h1>
        <div class="tel">
            <p>15196780978</p>
            <p>18190610788</p>
            <span>0817-3618388</span>
        </div>
       
<div class="mune">
    <svg t="1570411005191" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="8542" width="32" height="32"><path d="M905.848832 706.56c22.84544 0 41.744384 18.75968 41.744384 41.603072 0 23.6032-18.898944 42.364928-41.744384 42.364928L301.010944 790.528c-22.833152 0-41.728-18.75968-41.728-42.364928 0-22.843392 18.896896-41.603072 41.728-41.603072L905.848832 706.56zM139.56096 215.488512c29.927424 0 53.557248 24.406016 53.557248 53.54496 0 29.927424-23.631872 53.559296-53.557248 53.559296C110.422016 322.592768 86.016 298.960896 86.016 269.033472 86.016 239.894528 110.422016 215.488512 139.56096 215.488512L139.56096 215.488512zM301.010944 317.44c-22.833152 0-41.728-19.13856-41.728-41.984s18.896896-41.984 41.728-41.984l604.837888 0c22.84544 0 41.744384 19.13856 41.744384 41.984s-18.898944 41.984-41.744384 41.984L301.010944 317.44zM301.010944 569.344c-22.833152 0-41.728-19.140608-41.728-41.984s18.896896-41.984 41.728-41.984l604.837888 0c22.84544 0 41.744384 19.140608 41.744384 41.984s-18.898944 41.984-41.744384 41.984L301.010944 569.344zM139.56096 458.835968c29.927424 0 53.557248 23.63392 53.557248 53.557248 0 29.140992-23.631872 53.557248-53.557248 53.557248C110.422016 565.950464 86.016 541.534208 86.016 512.393216 86.016 482.46784 110.422016 458.835968 139.56096 458.835968L139.56096 458.835968zM139.56096 701.407232c29.927424 0 53.557248 24.420352 53.557248 53.559296 0 29.925376-23.631872 53.54496-53.557248 53.54496C110.422016 808.511488 86.016 784.893952 86.016 754.968576 86.016 725.827584 110.422016 701.407232 139.56096 701.407232L139.56096 701.407232z" p-id="8543" fill="#253f8e"></path></svg>        
    </div>
    </div>
    <div class="nav_bg">
        <div class="nav">
            <ul>
                <li class="nav_active"><a href="/">网站首页</a></li>
                <li><a href="/cpzx/gnxdp/">产品中心</a></li>
                <li><a href="/gywm/gsjj/">关于我们</a></li>
                <li><a href="/xwzx/qyzx/">新闻资讯</a></li>
                <li><a href="/gcal/zxal/">最新案例</a></li>
                <li><a href="/gcal/jdal/">经典案例</a></li>
                <li><a href="/gssl/ryzz/">公司实力</a></li>
                <li><a href="/lxwm/">联系我们</a></li>
            </ul>
        </div>
    </div>
</div>
<div class="ny_banner">
<div><img src="/images/2019092011404080.jpg" alt="" /></div>
</div>
<div class="rmgjc_bg">
    <div class="rmgjc wow fadeInUp">
        <div class="gjc"><span>热门关键词：</span>
        <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq(1,3,0,0);
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
        <a href="<?=$bqsr['titleurl']?>"><?=$bqr['title']?></a>
        <?php
}
}
?>
        </div>
        
    </div>
</div>
<div class="ny_main">
    <div class="ny_news">
        <div class="ny_l">
            <div class="product_l product_l2">
                <dl>
                    <dt><img src="/images/ny_news_l_title.png" alt=""></dt>

                    
                    <? @sys_ShowClassByTemp(3,1,0,0);?>

                </dl>
            </div>
            <div class="ny_con">
                <ul>
                    <li>
                        <h1>联系我们</h1>
                        <img src="/images/ny_lxwm.jpg" alt="">
                        <p>
                            手  机：15196780978(王经理)<br />
                            邮  箱：1024957682@qq.com<br />
                            地  址：四川省南充市川东北金融广场五栋18-22号
                        </p>
                    </li>
                </ul>
            </div>
        </div>

        <div class="ny_news_content">
            <div class="daohang"><p>当前位置：[!--newsnav--]</div>
            <ul class="news_list">
                


                    [!--empirenews.listtemp--]
                    <!--list.var1-->
                    [!--empirenews.listtemp--]

            </ul>
           <div class="pageBox">[!--show.listpage--]</div>
           <style type="text/css">
            .pageBox {text-align: center; width:90%; margin-bottom:25px; margin-top:25px; }
            .pageBox a {border:1px solid #ddd;display:inline-block;margin-right:6px;color: #707070;width:45px;height:34px;font:bold 14px/34px arial;}
            .pageBox a:hover,.pageBox a:active{background:#3aa9f2;color: #FFFFFF;text-decoration: none;}
            .pageBox .cur { background: #3aa9f2;border: 1px solid #3aa9f2;text-decoration: none;}
            .pageBox a.cur {color: #fff;}
            .pageBox .disabled {width: 79px;}
</style>
        </div>
    </div>
</div>
<div class="footer">
    <div class="footer1">
        <div class="ewm wow rollIn"><img src="/images/ewm.jpg" /><p>扫一扫，关注我们</p></div>
        <div class="bot_nav">
            <div class="bot_nav1">
                <a href="/cpzx/gnxdp/">产品中心</a>
                <a href="/gywm/gsjj/">关于我们</a>
                <a href="/xwzx/qyzx/">新闻资讯</a>
                <a href="/gcal/zxal/">最新案例</a>
                <a href="/gcal/jdal/">经典案例</a>
                <a href="/gssl/rrzz/">公司实力</a>
                <a href="/lxwm/">联系我们</a>
            </div>
        </div>
        <div class="bot_txt">
            <span>手  机：15196780978(王经理)</span><span>座  机：0817-3618388</span><span>邮  箱：1024957682@qq.com</span>
            <span>地  址：四川省南充市川东北金融广场五栋18-22号</span>
        </div>
        <div class="copy">Copyrights  南充市丽邦装饰工程有限公司版权所有    <a href="https://beian.miit.gov.cn/#/Integrated/index" target="_blank" style="color:#fff">蜀ICP备14005687号-1</a><br>
        技术支持 ：<a href="https://www.shunking.cn/" style="color: #fff"> 舜王科技</a>
        </div>

    </div>

</div>
<style>
       .bot_txt span {
    margin-right: 28px;
}
</style>
<div class="footers">
    <ul>
        <li><p><img src="/images/b_ico1.png" /><a href="/">首页</a></p></li>
        <li><p><img src="/images/b_ico2.png" /><a href="tel:15196780978">一键呼叫</a></p></li>
        <li><p><img src="/images/b_ico3.png" /><a href="/cpzx/gnxdp/">产品中心</a></p></li>
        <li><p><img src="/images/b_ico4.png" /><a href="/gywm/gsjj/">关于我们</a></p></li>
    </ul>
</div>
<script src="/js/kefu.js" type="text/javascript"></script>
<div id="kefu"></div>
<script src="/js/wow.min.js" type="text/javascript"></script>
<script type="text/javascript" src="/js/base.js"></script>
</body>
</html>
