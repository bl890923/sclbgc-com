<?php
if(!defined('InEmpireCMS'))
{
	exit();
}
?><!DOCTYPE html
    PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport"
        content="width=device-width;minimum-scale=1,maximum-scale=1,initial-scale=1,user-scalable=no" />
    <meta name="applicable-device" content="pc,mobile" />
    <title>网站首页 - 南充市丽邦装饰工程有限公司</title>
    <meta name="keywords" content="南充市丽邦装饰工程有限公司" />
    <meta name="description" content="南充市丽邦装饰工程有限公司，是一家集设计、营销、安装、客服、施工团队为一体，为客户提供一站式服务的专业品牌的康体企业，一直致力于打造“你的满意我们的无限动力”的品牌形象，专注的态度，专业的技术，严谨的全方位的跟踪服务，竭尽所能为用户提供更多、更好、更完善的地坪工程。
我们一贯十分重视工程质量，注重施工队伍的建设，拥有各种场地经验的工程技术人员，而且还引进了专业的施工机械设备，使工程建设队伍无论在技术质量还是技术装备方面，都有着无法比拟的优势，经过各类工程的锤炼，目前公司施工队伍有着丰富的施工经验和较强的技术实力，完全有能力完成各类型场地的施工。
公司拥有先进的生产基地和设施完备的实验中心。主要产品有：环氧自流坪，环氧砂浆地坪，环氧薄涂地坪，车库交通设施，塑胶跑道，硅PU球场，丙烯酸球场，以及环氧树脂玻纤地板、环氧树脂防静电地板、环氧防腐地板、水性环氧地板、 PVC塑胶地板,全钢防静电地板、透水地板、艺术地板、金刚砂耐磨地板及化学腐蚀的防腐处理等。产品主要应用于：精密仪器、食品工间、烟草、光学生物制品、学校、商场、车场等领域。 
公司努力传播先进涂装理念，积极参与行业标准的制定，始终以材料技术、涂装工艺创新作为企业生存与发展的动力，在产品研发，施工工艺上孜孜以求，不断推出具有自主知识产权的核心技术。
丽邦用心为顾客提供优质产品和专业化的技术服务，积极推崇绿色环保产品，树立企业的社会责任形象，是工业地坪系统方案的解决专家，领先的产品品质及优质的服务使丽邦在行业内有着卓著的口碑和业绩。" />
    <link rel="stylesheet" type="text/css" href="/css/reset.css" />
    <link rel="stylesheet" type="text/css" href="/css/css.css" />
    <link rel="stylesheet" type="text/css" href="/css/animate.css" />
    <link rel="stylesheet" type="text/css" href="/css/jquery-ui.css" />
    <link rel="stylesheet" type="text/css" href="/css/flexslider.css" />
    <link rel="stylesheet" type="text/css" href="/css/responsive.css" />
    <script type="text/javascript" src="/js/jquery.min.js"></script>
    <script type="text/javascript" src="/js/jquery-ui.js"></script>
    <script type="text/javascript" src="/js/jquery.flexslider-min.js"></script>
    <script type="text/javascript" src="/js/jquery.SuperSlide.2.1.1.js"></script>
    <script src="/js/Search.js" type="text/javascript"></script>
</head>

<body>
    <div class="header">
    <div class="header_center">
        <h1 class="logo wow zoomIn"><a href="/"><img width="64px" height="64px" src="/images/logo.png" title="南充市丽邦装饰工程有限公司" alt="南充市丽邦装饰工程有限公司" /><img class="logo_txt" src="/images/logo_txt.png" alt=""></a></h1>
        <div class="tel">
            <p>15196780978</p>
            <p>18190610788</p>
            <span>0817-3618388</span>
        </div>
       
<div class="mune">
    <svg t="1570411005191" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="8542" width="32" height="32"><path d="M905.848832 706.56c22.84544 0 41.744384 18.75968 41.744384 41.603072 0 23.6032-18.898944 42.364928-41.744384 42.364928L301.010944 790.528c-22.833152 0-41.728-18.75968-41.728-42.364928 0-22.843392 18.896896-41.603072 41.728-41.603072L905.848832 706.56zM139.56096 215.488512c29.927424 0 53.557248 24.406016 53.557248 53.54496 0 29.927424-23.631872 53.559296-53.557248 53.559296C110.422016 322.592768 86.016 298.960896 86.016 269.033472 86.016 239.894528 110.422016 215.488512 139.56096 215.488512L139.56096 215.488512zM301.010944 317.44c-22.833152 0-41.728-19.13856-41.728-41.984s18.896896-41.984 41.728-41.984l604.837888 0c22.84544 0 41.744384 19.13856 41.744384 41.984s-18.898944 41.984-41.744384 41.984L301.010944 317.44zM301.010944 569.344c-22.833152 0-41.728-19.140608-41.728-41.984s18.896896-41.984 41.728-41.984l604.837888 0c22.84544 0 41.744384 19.140608 41.744384 41.984s-18.898944 41.984-41.744384 41.984L301.010944 569.344zM139.56096 458.835968c29.927424 0 53.557248 23.63392 53.557248 53.557248 0 29.140992-23.631872 53.557248-53.557248 53.557248C110.422016 565.950464 86.016 541.534208 86.016 512.393216 86.016 482.46784 110.422016 458.835968 139.56096 458.835968L139.56096 458.835968zM139.56096 701.407232c29.927424 0 53.557248 24.420352 53.557248 53.559296 0 29.925376-23.631872 53.54496-53.557248 53.54496C110.422016 808.511488 86.016 784.893952 86.016 754.968576 86.016 725.827584 110.422016 701.407232 139.56096 701.407232L139.56096 701.407232z" p-id="8543" fill="#253f8e"></path></svg>        
    </div>
    </div>
    <div class="nav_bg">
        <div class="nav">
            <ul>
                <li class="nav_active"><a href="/">网站首页</a></li>
                <li><a href="/cpzx/gnxdp/">产品中心</a></li>
                <li><a href="/gywm/gsjj/">关于我们</a></li>
                <li><a href="/xwzx/qyzx/">新闻资讯</a></li>
                <li><a href="/gcal/zxal/">最新案例</a></li>
                <li><a href="/gcal/jdal/">经典案例</a></li>
                <li><a href="/gssl/ryzz/">公司实力</a></li>
                <li><a href="/lxwm/">联系我们</a></li>
            </ul>
        </div>
    </div>
</div>
    <div class="banner">
        <section class="slider">
            <div class="flexslider">
                <ul class="slides">
                    <li><img src='/images/banner01.jpg' /></li>
                    <li><img src='/images/banner02.jpg' /></li>
                    <li><img src='/images/banner03.jpg' /></li>
                </ul>
            </div>
        </section>
    </div>
    <div class="rmgjc_bg">
        <div class="rmgjc wow fadeInUp">
            <div class="gjc"><span>热门关键词：</span>


                <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq(1,3,0,0);
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                <a href="<?=$bqsr['titleurl']?>"><?=$bqr['title']?></a>
                <?php
}
}
?>
            </div>


        </div>
    </div>
    <div class="anli">
        <div class="sy_title wow fadeInUp">
            <p>工程案例</p>
            <i>CASE</i>
            <span>完善的质量保证体系和售后服务体系</span>
        </div>
        <div class="anli_content wow fadeInUp">
            <div class="picScroll-left">
                <a class="next"></a>
                <div class="bd">
                    <ul class="picList">


                        <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq(18,10,0,1);
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                        <li>
                            <div class='pic'><a href='<?=$bqsr['titleurl']?>'><img src='<?=$bqr['titlepic']?>' /></a>
                            </div>
                            <div class='title'><a href='<?=$bqsr['titleurl']?>'><?=$bqr['title']?></a></div>
                        </li>
                        <?php
}
}
?>

                    </ul>
                </div>
                <a class="prev"></a>
            </div>
        </div>
        <a href="/gcal/zxal/">了解更多</a>
    </div>
    <div class="product_bg">
        <div class="product">
            <div class="sy_title wow fadeInUp">
                <p>产品中心</p>
                <i>PRODUCTS</i>
                <span>完善的质量保证体系和售后服务体系</span>
            </div>
            <div class="product_content">


                <div class='product_list wow fadeInLeft'>
                    <a href="/cpzx/gnxdp/">特殊地坪系列</a>
                    <dl>
                        <dt><img src='/images/pro_fl_img1.jpg'></dt>
                        <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq(7,20,0,1);
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                        <dd><a href="<?=$bqsr['titleurl']?>"><?=$bqr['title']?></a></dd>
                        <?php
}
}
?>
                    </dl>
                </div>

                <div class='product_list wow fadeInLeft'>
                    <a href="/cpzx/hydp/">环氧地坪系列</a>
                    <dl>
                        <dt><img src='/images/pro_fl_img2.jpg'></dt>
                        <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq(8,20,0,1);
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                        <dd><a href="<?=$bqsr['titleurl']?>"><?=$bqr['title']?></a></dd>
                        <?php
}
}
?>
                    </dl>
                </div>


                <div class='product_list wow fadeInLeft'>
                    <a href="/cpzx/gdsydp/">高端商业地坪系列</a>
                    <dl>
                        <dt><img src='/images/pro_fl_img3.jpg'></dt>
                        <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq(9,20,0,1);
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                        <dd><a href="<?=$bqsr['titleurl']?>"><?=$bqr['title']?></a></dd>
                        <?php
}
}
?>
                    </dl>
                </div>

                <div class='product_list wow fadeInLeft'>
                    <a href="/cpzx/hwydcs/">户外及运动场所系列</a>
                    <dl>
                        <dt><img src='/images/pro_fl_img4.jpg'></dt>
                        <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq(10,20,0,1);
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                        <dd><a href="<?=$bqsr['titleurl']?>"><?=$bqr['title']?></a></dd>
                        <?php
}
}
?>
                    </dl>
                </div>

                <div class='product_list wow fadeInLeft'>
                    <a href="/cpzx/dpcl/">地坪材料</a>
                    <dl>
                        <dt><img src='/images/pro_fl_img5.jpg'></dt>
                        <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq(11,20,0,1);
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                        <dd><a href="<?=$bqsr['titleurl']?>"><?=$bqr['title']?></a></dd>
                        <?php
}
}
?>
                    </dl>
                </div>

            </div>
        </div>
    </div>

    <div class="abouts">
        <div class="abouts1">
            <div class="sy_title wow fadeInUp">
                <p>关于丽邦</p>
                <i>ABOUT US</i>
                <span>完善的质量保证体系和售后服务体系</span>
            </div>
            <div class="shipin wow fadeInRight">
                <div id="a1"></div>
                <script type="text/javascript" src="/js/ckplayer.js" charset="utf-8"></script>
                <script type="text/javascript">
                    var flashvars = { f: '/images/shipin.mp4', c: 0, wh: '16:9' };
                    var params = { allowFullScreen: true, allowScriptAccess: 'always', wmode: 'transparent' };
                    var video = ['/images/shipin.mp4->video/mp4'];
                    CKobject.embed('/images/ckplayer.swf', 'a1', 'ckplayer_a1', '351.2', '200', true, flashvars, video, params);
                </script>
                <br/>
                <div id="a2"></div>
                <script type="text/javascript" src="/js/ckplayer.js" charset="utf-8"></script>
                <script type="text/javascript">
                    var flashvars1 = { f: '/images/shipin1.mp4', c: 0, wh: '16:9' };
                    var params1 = { allowFullScreen: true, allowScriptAccess: 'always', wmode: 'transparent' };
                    var video1 = ['/images/shipin1.mp4->video/mp4'];
                    CKobject.embed('/images/ckplayer.swf', 'a2', 'ckplayer_a2', '351.2', '200', true, flashvars1, video1, params1);
                </script>

            </div>
            <div class="abouts_txt wow fadeInLeft">
                <p> 南充市丽邦装饰工程有限公司，是一家集设计、营销、安装、客服、施工团队为一体，为客户提供一站式服务的专业品牌的康体企业，一直致力于打造“你的满意我们的无限动力”的品牌形象，专注的态度，专业的技术，严谨的全方位的跟踪服务，竭尽所能为用户提供更多、更好、更完善的地坪工程。
                </p><br />
                <p>我们一贯十分重视工程质量，注重施工队伍的建设，拥有各种场地经验的工程技术人员，而且还引进了专业的施工机械设备，使工程建设队伍无论在技术质量还是技术装备方面，都有着无法比拟的优势，经过各类工程的锤炼，目前公司施工队伍有着丰富的施工经验和较强的技术实力，完全有能力完成各类型场地的施工。
                </p>
                <a href="/gywm/gsjj/">了解详情</a>
            </div>
        </div>
    </div>

    <div class="youshi wow fadeInUp">
        <div class="youshi_title">
            <p><img src="/images/youshi_title.jpg" alt=""></p>
            <span><img src="/images/youshi_img.jpg" alt=""></span>
        </div>
        <div class="youshi_content">
            <div class="youshi_1 wow bounceInLeft">
                <img src="/images/youshi_img2.jpg" alt="">
                <div class="youshi_1_txt">
                    <i><img src="/images/youshi_ico1.png" alt=""></i>
                    <span>做有针对性地坪设计</span>
                    <p>
                        <font>★</font>考察原基层地面，做好数据分析；<br />
                        <font>★</font>详听甲方需求，匹配优质材料；<br />
                        <font>★</font>探讨设计结果，确定设计方案。
                    </p>
                </div>
            </div>
            <div class="youshi_1 youshi_2 wow bounceInRight">
                <div class="youshi_1_txt">
                    <i><img src="/images/youshi_ico2.png" alt=""></i>
                    <span>二十年生产施工经验</span>
                    <p>
                        <font>★</font>生产施工负责人二十年相关经验，综合解决各种地坪需求；<br />
                        <font>★</font>多年培养施工队伍二百余人；<br />
                        <font>★</font>两千多项地坪案列，专为同行提供有偿技术支持。
                    </p>
                    <div class="youshi_1_txt">
                        <i><img src="/images/youshi_ico3.png" alt=""></i>
                        <span>管家式服务，售后有保障</span>
                        <p>
                            <font>★</font>所有项目存档保存，终身售后支持；<br />
                            <font>★</font>定期回访，指导使用、保养措施；<br />
                            <font>★</font>不管项目大小，一视同仁。
                        </p>
                    </div>
                </div>
                <img src="/images/youshi_img3.jpg" alt="">
            </div>
            <div class="youshi_1 wow bounceInLeft">
                <img src="/images/youshi_img4.jpg" alt="">
                <div class="youshi_1_txt">
                    <i><img src="/images/youshi_ico4.png" alt=""></i>
                    <span>专业资质</span>

                    <div class="picMarquee-left">
                        <div class="bd">
                            <ul class="picList">

                                <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq(20,10,0,1);
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                                <li>
                                    <div class="pic"><img src="<?=$bqr['titlepic']?>" /></div>
                                </li>
                                <?php
}
}
?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="huoban wow fadeInUp">
        <div class="huoban_title">
            <img src="/images/huoban_title.png" alt="">
        </div>
        <div class="huoban_content">
            <ul>

                <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq(21,8,0,1);
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                <li><img src="<?=$bqr['titlepic']?>" /></li>
                <?php
}
}
?>
            </ul>
        </div>
    </div>
    <div class="news wow fadeInUpBig">
        <div class="sy_title wow fadeInUp">
            <p>新闻资讯</p>
            <i>NEWS</i>
            <span>完善的质量保证体系和售后服务体系</span>
        </div>
        <div class="news_content">
            <ul class="news_l wow fadeInLeft">
                <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq(3,4,0,1);
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
                <li><img src='<?=$bqr['titlepic']?>'>
                    <div class='news_txt'><a href='<?=$bqsr['titleurl']?>'><?=$bqr['title']?>?</a><span>03-09</span>
                        <p><?=$bqr[smalltext]?>...</p>
                    </div>
                </li>

                <?php
}
}
?>


            </ul>
        </div>
        <a href="/xwzx/qyzx/">查看更多</a>
    </div>

    <div class="footer">
    <div class="footer1">
        <div class="ewm wow rollIn"><img src="/images/ewm.jpg" /><p>扫一扫，关注我们</p></div>
        <div class="bot_nav">
            <div class="bot_nav1">
                <a href="/cpzx/gnxdp/">产品中心</a>
                <a href="/gywm/gsjj/">关于我们</a>
                <a href="/xwzx/qyzx/">新闻资讯</a>
                <a href="/gcal/zxal/">最新案例</a>
                <a href="/gcal/jdal/">经典案例</a>
                <a href="/gssl/rrzz/">公司实力</a>
                <a href="/lxwm/">联系我们</a>
            </div>
        </div>
        <div class="bot_txt">
            <span>手  机：15196780978(王经理)</span><span>座  机：0817-3618388</span><span>邮  箱：1024957682@qq.com</span>
            <span>地  址：四川省南充市川东北金融广场五栋18-22号</span>
        </div>
        <div class="copy">Copyrights  南充市丽邦装饰工程有限公司版权所有    <a href="https://beian.miit.gov.cn/#/Integrated/index" target="_blank" style="color:#fff">蜀ICP备14005687号-1</a><br>
        技术支持 ：<a href="https://www.shunking.cn/" style="color: #fff"> 舜王科技</a>
        </div>

    </div>

</div>
<style>
       .bot_txt span {
    margin-right: 28px;
}
</style>
<div class="footers">
    <ul>
        <li><p><img src="/images/b_ico1.png" /><a href="/">首页</a></p></li>
        <li><p><img src="/images/b_ico2.png" /><a href="tel:15196780978">一键呼叫</a></p></li>
        <li><p><img src="/images/b_ico3.png" /><a href="/cpzx/gnxdp/">产品中心</a></p></li>
        <li><p><img src="/images/b_ico4.png" /><a href="/gywm/gsjj/">关于我们</a></p></li>
    </ul>
</div>
    <script src="/js/kefu.js" type="text/javascript"></script>
    <div id="kefu"></div>
    <script type="text/javascript" src="/js/base.js"></script>
    <script type="text/javascript" src="/js/slick.js"></script>
    <script type="text/javascript" src="/js/wow.min.js"></script>
    <script type="text/javascript" src="/js/rem.min.js"></script>
</body>

</html>