<?php
if(!defined('InEmpireCMS'))
{
	exit();
}
?></td>
        </tr>
      </table></td>
</tr>
</table>
<div class="footer">
    <div class="footer1">
        <div class="ewm wow rollIn"><img src="/images/ewm.jpg" /><p>扫一扫，关注我们</p></div>
        <div class="bot_nav">
            <div class="bot_nav1">
                <a href="/cpzx/gnxdp/">产品中心</a>
                <a href="/gywm/gsjj/">关于我们</a>
                <a href="/xwzx/qyzx/">新闻资讯</a>
                <a href="/gcal/zxal/">最新案例</a>
                <a href="/gcal/jdal/">经典案例</a>
                <a href="/gssl/rrzz/">公司实力</a>
                <a href="/lxwm/">联系我们</a>
            </div>
        </div>
        <div class="bot_txt">
            <span>手  机：15196780978(王经理)</span><span>座  机：0817-3618388</span><span>邮  箱：1024957682@qq.com</span>
            <span>地  址：四川省南充市川东北金融广场五栋18-22号</span>
        </div>
        <div class="copy">Copyrights  南充市丽邦装饰工程有限公司版权所有    <a href="https://beian.miit.gov.cn/#/Integrated/index" target="_blank" style="color:#fff">蜀ICP备14005687号-1</a><br>
        技术支持 ：<a href="https://www.shunking.cn/" style="color: #fff"> 舜王科技</a>
        </div>

    </div>

</div>
<style>
       .bot_txt span {
    margin-right: 28px;
}
</style>
<div class="footers">
    <ul>
        <li><p><img src="/images/b_ico1.png" /><a href="/">首页</a></p></li>
        <li><p><img src="/images/b_ico2.png" /><a href="tel:15196780978">一键呼叫</a></p></li>
        <li><p><img src="/images/b_ico3.png" /><a href="/cpzx/gnxdp/">产品中心</a></p></li>
        <li><p><img src="/images/b_ico4.png" /><a href="/gywm/gsjj/">关于我们</a></p></li>
    </ul>
</div>
</body>
</html>