<?php
$notcj_r=array();
$notcj_r[1]='<input type=hidden value=\'欢迎使用帝国网站管理系统：www.phome.net\'>';
$notcj_r[2]='<phome 帝国网站管理系统,phome.net>';
$notcj_r[3]='<!--帝国CMS,phome.net-->';
$notcj_r[4]='<table style=display=none><tr><td>
Empire CMS,phome.net
</td></tr></table>';
$notcj_r[5]='<div style=display=none>
拥有帝国一切，皆有可能。欢迎访问phome.net
</div>';
$notcjnum=5;
?>