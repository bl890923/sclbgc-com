<?php
if(!defined('InEmpireCMS'))
{
	exit();
}
$class_r=array();
$class_zr=array();
$class_tr=array();
$eyh_r=array();
require(ECMS_PATH.'e/data/dbcache/class1.php');
require(ECMS_PATH.'e/data/dbcache/ztclass.php');




?>